import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.TreeMap;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;


public class TopMoviesMain {

	public static String splitChar = "::";
	public static String splitCharSpace = " ";
	public static int totalOutput = 10;
	
	//average mapper
	public static class Map extends Mapper<Object, Text, IntWritable, DoubleWritable> {
		
		private IntWritable movieID= new IntWritable();
		private DoubleWritable usrRating= new DoubleWritable();
		
	    public void map(Object key, Text value, Context context) throws IOException, InterruptedException 
	    {
	    	
	    	String line = value.toString();
	    	String []tokens = line.split(TopMoviesMain.splitChar);
	    	
	    	movieID.set(Integer.parseInt(tokens[1].trim()));
	    	usrRating.set(Double.parseDouble(tokens[2].trim()));
	    	
	    	context.write(movieID, usrRating);
    	}
	 } 
	        
	 //average reducer
	 public static class Reduce extends Reducer<IntWritable, DoubleWritable, IntWritable, DoubleWritable> 
	 {
		private DoubleWritable outvalue = new DoubleWritable();
		 
		public void reduce(IntWritable key, Iterable<DoubleWritable> values, Context context) throws IOException, InterruptedException 
		{
			
			double sum = 0.0;
			double count = 0;
			
			for (DoubleWritable rating : values) 
			{
				sum += rating.get();
				++count;
			}
			
			outvalue.set(sum/count);
			context.write(key, outvalue);
		}
	 }
	 
	 //top10 mapper
	 public static class Top10Mapper extends Mapper<Object, Text, NullWritable, Text> 
	 {			
		private IntWritable movieID= new IntWritable();
		private DoubleWritable usrRating= new DoubleWritable();
		private ArrayList<int[]> mvID = new ArrayList<int[]>();
		private ArrayList<Double> usrR = new ArrayList<Double>();
		private Text outValue = new Text();
		
		private TreeMap<Double, Integer> top10TreeMapObj = new TreeMap<Double, Integer>();
		
	    public void map(Object key, Text value, Context context) throws IOException, InterruptedException 
	    {	    	
	    	String line = value.toString();
	    	StringTokenizer tokens = new StringTokenizer(line);
	    	
	    	try
	    	{
	    		while (tokens.hasMoreTokens()) {
	    			int valueE = Integer.parseInt(tokens.nextToken().trim());
	    			double keyE = Double.parseDouble(tokens.nextToken().trim());
	    			
	    			if(top10TreeMapObj.containsKey(keyE))
	    			{
	    				if(usrR.indexOf(keyE)>=0)
	    				{
		    				int[] idList = mvID.get(usrR.indexOf(keyE));	    				
		    				int[] updatedIdList = new int[idList.length+1];
							System.arraycopy(idList, 0, updatedIdList, 0, idList.length);
							
							updatedIdList[idList.length] = valueE;
							mvID.set(usrR.indexOf(keyE), updatedIdList);
	    				}
	    				else
	    				{
	    					int[] id = new int[1];
							id[0] = valueE;
							mvID.add(id);
							usrR.add(keyE);
	    				}
	    			}
	    			else
	    				top10TreeMapObj.put(keyE,valueE);
	    			
	    			if(top10TreeMapObj.size()>TopMoviesMain.totalOutput)
			    	{
			    		top10TreeMapObj.remove(top10TreeMapObj.firstKey());
			    	}
	    		}
	    	}
	    	catch (Exception ex) {
				// TODO: handle exception
			}
    	}
	    
	    protected void cleanup(Context context) throws IOException, InterruptedException 
	    {
	    	int c = 0;
		    while(!top10TreeMapObj.isEmpty())
		    {
		    	double key = top10TreeMapObj.lastKey();
		    	usrRating.set(key);
		    	movieID.set(top10TreeMapObj.get(key));
		    	outValue.set(top10TreeMapObj.get(key) +"\t"+ key);
		    	
		    	top10TreeMapObj.remove(key);
		    	
		    	context.write(NullWritable.get(),outValue);
		    	
		    	c++;
		    	
		    	if(usrR.indexOf(key)>=0)
		    	{
			    	int len = mvID.get(usrR.indexOf(key)).length;
			    	int[] idList = mvID.get(usrR.indexOf(key));
			    	for(int i=0;i<len;i++)
			    	{
			    		movieID.set(idList[i]);
			    		outValue.set(idList[i] +"\t"+ key);
			    		context.write(NullWritable.get(),outValue);
			    		c++;
			    		
			    		if(c>=TopMoviesMain.totalOutput) break;
			    	}
		    	}
		    	if(c>=TopMoviesMain.totalOutput) break;
		    }
	    }
	 } 
		   
	 //top10 reducer
	 public static class Top10Reducer extends Reducer<NullWritable, Text, NullWritable, Text> 
	 {
		public void reduce(NullWritable key, Iterable<Text> values, Context context) throws IOException, InterruptedException 
		{
			for(Text rating : values)
			{
				context.write(NullWritable.get(), rating);
			}
		}
	 }
		 
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception
	{
		// TODO Auto-generated method stub
		Configuration conf = new Configuration();        
	    Job job = new Job(conf, "TopMoviesMain");
	    
	    job.setOutputKeyClass(IntWritable.class);
	    job.setOutputValueClass(DoubleWritable.class);
	    job.setJarByClass(TopMoviesMain.class);
	    job.setMapperClass(Map.class);
	    job.setCombinerClass(Reduce.class);
	    job.setReducerClass(Reduce.class);
	        
	    job.setInputFormatClass(TextInputFormat.class);
	    job.setOutputFormatClass(TextOutputFormat.class);
	        
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job, new Path(args[1]+"_int"));
	        
	    int code = job.waitForCompletion(true) ? 0 : 1;
	    
	    if(code==0)
	    {
	    	Job job2 = new Job(conf, "Top10MoviesMain");
		    
		    job2.setOutputKeyClass(NullWritable.class);
		    job2.setOutputValueClass(Text.class);
		    job2.setJarByClass(TopMoviesMain.class);
		    job2.setMapperClass(Top10Mapper.class);
		    //job2.setCombinerClass(Top10Reducer.class);
		    job2.setReducerClass(Top10Reducer.class);
		        
		    job2.setInputFormatClass(TextInputFormat.class);
		    job2.setOutputFormatClass(TextOutputFormat.class);
		        
		    FileInputFormat.addInputPath(job2, new Path(args[1]+"_int"));
		    FileOutputFormat.setOutputPath(job2, new Path(args[1]));
		        
		    job2.waitForCompletion(true);
	    }
	}

}
