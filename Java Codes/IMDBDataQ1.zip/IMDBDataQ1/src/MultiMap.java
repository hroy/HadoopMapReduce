import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;


public class MultiMap {
	private TreeMap<Double, List<String>> treeMap = new TreeMap<Double, List<String>>();

    public void add(double key, String value) {
        
        List<String> values = new ArrayList<String>();
        if (treeMap.containsKey(key)) {

            values = treeMap.get(key);
            values.add(value);

            treeMap.put(key, values);
        } else {

            values.add(value);

            treeMap.put(key, values);
        }

    }

    public int getMultiMapSize() {
        int size = 0;
        for (Double key : treeMap.keySet()) {
            ArrayList<String> values = (ArrayList<String>) treeMap.get(key);
            size += values.size();
        }

        return size;
    }

    public void removeFirstElement() {
        ArrayList<String> values = (ArrayList<String>) treeMap.get(treeMap.firstKey());
        if (values.size() < 2) {
            treeMap.remove(treeMap.firstKey());
        } else {
            String firstValue = values.get(0);
            values.remove(firstValue);
        }
    }

    public ArrayList<String> topNElement(int n) {
        ArrayList<String> topNElementValues = new ArrayList<String>();

        for (Double key : treeMap.descendingKeySet()) {
            if (n == 0) {
                break;
            }

            ArrayList<String> values = (ArrayList<String>) treeMap.get(key);
            
            for (String val : values) {
                if (n == 0) {
                    break;
                }

                if (n > 0) {
                    topNElementValues.add(val + "\t" + key);
                    n--;
                }

            }
        }
        return topNElementValues;
    }
}
