import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.GZIPInputStream;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;


public class MoviesMSJoin {

	public static String splitCharColon = "::";
	public static String splitCharTab = "\t";
	public static String inputGenre = "Action";
	
	public static class AverageMapper extends Mapper<Object, Text, Text, IntWritable> {

        private Text outKeyValue = new Text();

//        private static final Text EMPTY_TEXT = new Text("");
        private HashMap<String, String> mvIdnInfo = new HashMap<String, String>();
        
        public void setup(Context context) throws IOException,InterruptedException {
	        
        	Path[] files = DistributedCache.getLocalCacheFiles(context.getConfiguration());
	        
	        for (Path p : files) {
		        BufferedReader rdr = new BufferedReader(
		        		new InputStreamReader(
		        						new FileInputStream(
		        								new File(p.toString()))));
		        String line = null;
		        while ((line = rdr.readLine()) != null) {
		        	String[] tokens = line.toString().trim().split(splitCharColon);
		        	if(tokens.length==3)
		        	{
				        String mvId = tokens[0].trim();
				        String mvName = tokens[1].trim();
				        String mvGenre = tokens[2].trim();
				        
				        if(mvGenre.toLowerCase().indexOf(inputGenre.trim().toLowerCase())>=0)
				        	mvIdnInfo.put(mvId, mvName +"\t"+ mvGenre);
		        	}
		        }
	        }
        }
        
        @Override
        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {

            String[] strArr = value.toString().trim().split(splitCharColon);

            if (strArr.length == 4) {
                String movieId = strArr[1].trim();
                
                if(mvIdnInfo.containsKey(movieId))
                {
	                int rating = Integer.parseInt(strArr[2].trim());
	
	                outKeyValue.set(movieId+"\t"+mvIdnInfo.get(movieId));
	                context.write(outKeyValue, new IntWritable(rating));
	                //context.write(outKeyValue, new DoubleWritable(rating));
                }
            }
        }
    }
	
	public static class AverageReducer extends Reducer<Text, IntWritable, Text, DoubleWritable> {

        @Override
        public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
        	double sum = 0;
            int count = 0;
            for (IntWritable val : values) {
                sum += val.get();
                count++;
            }
            
            context.write(key, new DoubleWritable(sum/count));
        }
    }
	
	public static class TopRatedMapper extends Mapper<Object, Text, NullWritable, Text> {

        MultiMap multiMap = new MultiMap();

        @Override
        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            String[] strArr = value.toString().split(splitCharTab);

            int l = strArr.length;
            int l2 = value.toString().length();
            if (l > 0) {
                multiMap.add(Double.parseDouble(strArr[l-1]), value.toString().substring(0, l2 - strArr[l-1].length()-1).trim());
                if (multiMap.getMultiMapSize() > 10) {
                    multiMap.removeFirstElement();
                }
            }
        }

        @Override
        protected void cleanup(Context context) throws IOException,InterruptedException {
            for (String t : multiMap.topNElement(10)) {
                context.write(NullWritable.get(), new Text(t));
            }
        }
    }

    public static class TopRatedReducer extends Reducer<NullWritable, Text, NullWritable, Text> {

        MultiMap multiMap = new MultiMap();

        public void reduce(NullWritable key, Iterable<Text> values, Context context) throws IOException, InterruptedException {

            for (Text val : values) {

                String value = val.toString();
                String[] strArr = value.split(splitCharTab);

                int l = strArr.length;
                int l2 = value.toString().length();
                if (strArr.length > 0) {
                    //multiMap.add(Double.parseDouble(strArr[1]), strArr[0]);
                	multiMap.add(Double.parseDouble(strArr[l-1]), value.toString().substring(0, l2 - strArr[l-1].length()-1).trim());
                    if (multiMap.getMultiMapSize() > 10) {
                        multiMap.removeFirstElement();
                    }
                }
            }


            for (String t : multiMap.topNElement(10)) {

                context.write(NullWritable.get(), new Text(t));

            }
        	
//        	for(Text rating : values)
//			{
//				context.write(NullWritable.get(), rating);
//			}
        }
    }
    
	@SuppressWarnings("deprecation")
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub

		Configuration conf = new Configuration();    
		
		if (args.length != 3) {
            System.err.println("Instruction: MoviesMSJoin <Ratings File Path> <Movies File Path> <Output>");
            System.exit(2);
        }
		
		FileSystem fs = FileSystem.get(conf);
        fs.delete(new Path(args[2]));
        fs.delete(new Path(args[2]+"_tmp"));
        
	    Job joinJob = new Job(conf, "MoviesMSJoin");
	    
	    Path moviesDCPath = new Path(args[1]); //Movie file
	    DistributedCache.addCacheFile(moviesDCPath.toUri(), joinJob.getConfiguration());
	    
	    joinJob.setOutputKeyClass(Text.class);
	    joinJob.setOutputValueClass(DoubleWritable.class);
	    
	    joinJob.setJarByClass(MoviesMSJoin.class);
	    joinJob.setMapperClass(AverageMapper.class);
	    joinJob.setReducerClass(AverageReducer.class);
	        
	    joinJob.setMapOutputKeyClass(Text.class);
	    joinJob.setMapOutputValueClass(IntWritable.class);
        
	    joinJob.setInputFormatClass(TextInputFormat.class);
	    joinJob.setOutputFormatClass(TextOutputFormat.class);
	    	        
	    FileInputFormat.addInputPath(joinJob, new Path(args[0]));
	    FileOutputFormat.setOutputPath(joinJob, new Path(args[2]+"_tmp"));
	        
	    //joinJob.waitForCompletion(true);
	    
	    if (joinJob.waitForCompletion(true)) {
	    	
            Job fetchTopJob = new Job(conf, "TopRatedMovies");
            
            fetchTopJob.setJarByClass(MoviesMSJoin.class);
            fetchTopJob.setMapperClass(TopRatedMapper.class);
            fetchTopJob.setReducerClass(TopRatedReducer.class);

            fetchTopJob.setOutputKeyClass(NullWritable.class);
            fetchTopJob.setOutputValueClass(Text.class);

            FileInputFormat.addInputPath(fetchTopJob, new Path(args[2]+"_tmp"));
            FileOutputFormat.setOutputPath(fetchTopJob, new Path(args[2]));

            System.exit(fetchTopJob.waitForCompletion(true) ? 0 : 1);
        }
	}

}
