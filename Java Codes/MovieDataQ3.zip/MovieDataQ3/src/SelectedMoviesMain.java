import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class SelectedMoviesMain {

	public static String splitChar = "::";
	public static String splitCharLine = "|";	
	
	public static class Map extends Mapper<Object, Text, NullWritable, Text> {
		
		private Text genre= new Text();
		private Text movie= new Text();
		
		public ArrayList<String> gArray = new ArrayList<String>();
		
	    public void map(Object key, Text value, Context context) throws IOException, InterruptedException 
	    {	    	
	    	String line = value.toString();
	    	String []tokens = line.split(SelectedMoviesMain.splitChar);
	    	
	    	movie.clear();
	    	genre.clear();
	    	movie.set(tokens[1].trim());
	    	genre.set(tokens[2].trim());	    	

	    	boolean flag = false;
	    	Configuration conf = context.getConfiguration();   
		    String Para = conf.get("para");
		    StringTokenizer inGenre = new StringTokenizer(Para,SelectedMoviesMain.splitCharLine);
		    
		    while(inGenre.hasMoreTokens())
		    {
		    	if(genre.toString().toLowerCase().indexOf(inGenre.nextToken().trim().toLowerCase())>=0) flag = true;
		    	else
		    	{
		    		flag = false;
		    		break;
		    	}
		    }
		    if(flag) context.write(NullWritable.get(),movie);
    	}
	 }

	public static class Reduce extends Reducer<NullWritable, Text, NullWritable, Text> 
	 {		 
		public void reduce(NullWritable key, Iterable<Text> values, Context context) throws IOException, InterruptedException 
		{			
			for (Text val : values) {
				context.write(NullWritable.get(),new Text(val));
			}
		}
	 }
	
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub

		Configuration conf = new Configuration();  
		
		String gList = "";
		gList = args[2];
		for(int i=3;i<args.length;i++)
		{
			gList = gList + SelectedMoviesMain.splitCharLine + args[i];
		}
		System.out.println("genre @main: "+gList);
		
		conf.set("para", gList);
	    Job job = new Job(conf, "CountMoviesMain");
	    
	    job.setOutputKeyClass(NullWritable.class);
	    job.setOutputValueClass(Text.class);
	    job.setJarByClass(SelectedMoviesMain.class);
	    job.setMapperClass(Map.class);
	    job.setCombinerClass(Reduce.class);
	    job.setReducerClass(Reduce.class);
	        
	    job.setInputFormatClass(TextInputFormat.class);
	    job.setOutputFormatClass(TextOutputFormat.class);
	    	        
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job, new Path(args[1]));
	        
	    job.waitForCompletion(true);
	}
}
