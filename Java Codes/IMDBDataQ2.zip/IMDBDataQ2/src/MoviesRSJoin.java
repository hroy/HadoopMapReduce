import java.io.IOException;
import java.util.ArrayList;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class MoviesRSJoin {
	public static String splitChar = "::";
	public static String splitCharSpace = "\t";
	
	public static String userType = "M";
	public static String genre1st = "Action";
	public static String genre2nd = "Drama";
	public static double lowAvgRating = 4.4;
	public static double highAvgRating = 4.7;
	
	public static class UsersMapper extends Mapper<Object, Text, Text, Text> {
		
		private Text userID= new Text();
		
	    public void map(Object key, Text value, Context context) throws IOException, InterruptedException 
	    {
	    	String[] strArr = value.toString().trim().split(splitChar);

            if (strArr.length == 5) {
                String usrId = strArr[0].trim();
                String usrGender = strArr[1].trim();
                
                if(usrGender.equalsIgnoreCase(userType))
                {
//                	userID.set("U"+value);
                	userID.set("U"+usrId);
	                context.write(new Text(usrId),userID);
                }
            }
    	}
	 } 
	
	public static class RatingsMapper extends Mapper<Object, Text, Text, Text> {
		
		private Text mvInfo = new Text();
		
	    public void map(Object key, Text value, Context context) throws IOException, InterruptedException 
	    {
	    	String[] strArr = value.toString().trim().split(splitChar);

            if (strArr.length == 4) {
                String usrId = strArr[0].trim();
                String mvId = strArr[1].trim();
                String usrRating = strArr[2].trim();
                
//                mvInfo.set("R"+value);
                mvInfo.set("R"+mvId+"\t"+usrRating+"\t"+usrId);
                context.write(new Text(usrId),mvInfo);
            }
    	}
	 }
	
	public static class UsersRatingJoinReducer extends Reducer<Text, Text, Text, Text> 
	 {		 
		//private Text tmp = new Text();
		private ArrayList<Text> listU = new ArrayList<Text>();
		private ArrayList<Text> listR = new ArrayList<Text>();
		
		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException 
		{	
			listU.clear();
			listR.clear();
			
			for (Text v : values) 
			{
				if (v.toString().trim().charAt(0) == 'U') {
					listU.add(new Text(v.toString().substring(1)));
				} 
				else if (v.toString().trim().charAt(0) == 'R') {
					listR.add(new Text(v.toString().substring(1)));
				}
			}
			
			if (!listU.isEmpty() && !listR.isEmpty()) {
				for (Text R : listR) {
					for (Text U : listU) {
						context.write(R, U);
					}
				}
			}
		}
	 }
	
	public static class MoviesMapper extends Mapper<Object, Text, Text, Text> {
		
		private Text outValue = new Text();
		
	    public void map(Object key, Text value, Context context) throws IOException, InterruptedException 
	    {
	    	String[] strArr = value.toString().trim().split(splitChar);

            if (strArr.length == 3) {
                String mvId = strArr[0].trim();
                String mvName = strArr[1].trim();
                String mvGenre = strArr[2].trim();
                
                if(mvGenre.indexOf(genre1st)>=0 || mvGenre.indexOf(genre2nd)>=0)
                {
                	outValue.set("M"+mvId+"\t"+mvName+"\t"+mvGenre);
                	//outValue.set("M"+value);
	                context.write(new Text(mvId),outValue);
                }
            }
    	}
	 } 

	public static class SelectedUsersRatingsMapper extends Mapper<Object, Text, Text, Text> {
		
		private Text outValue= new Text();
		
	    public void map(Object key, Text value, Context context) throws IOException, InterruptedException 
	    {
	    	String[] strArr = value.toString().trim().split(splitCharSpace);

            if (strArr.length != 0) {
                String mvId = strArr[0].trim();
                String usrRating = strArr[1].trim();
                
//                outValue.set("R"+mvId+"\t"+usrRating);
                outValue.set("R"+usrRating);
                context.write(new Text(mvId),outValue);
            }
    	}
	 } 

	public static class UsersRatingMoviesJoinReducer extends Reducer<Text, Text, Text, Text> 
	{		 
		//private Text tmp = new Text();
		private ArrayList<Text> listM = new ArrayList<Text>();
		private ArrayList<Text> listR = new ArrayList<Text>();
		
		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException 
		{	
			listM.clear();
			listR.clear();
			
			double sum = 0;
            int count = 0;
            
			for (Text v : values) 
			{
				if (v.toString().trim().charAt(0) == 'M') {
					listM.add(new Text(v.toString().substring(1)));
				} 
				else if (v.toString().trim().charAt(0) == 'R') {
					//listR.add(new Text(v.toString().substring(1)));
					sum = sum + Integer.parseInt(v.toString().substring(1).trim());
					count++;
					listR.add(new Text(v.toString().substring(1)));
				}
			}
			
			double rating = sum/count;
			if (!listM.isEmpty() && !listR.isEmpty()) {
//				for (Text M : listM) {
//					for (Text R : listR) {
//						context.write(M, R);
//					}
//				}
				for (Text M : listM)
				{
					if(rating>=lowAvgRating && rating<=highAvgRating)
		            {
						context.write(M, new Text(""+rating));
		            }
				}
			}
		}
	 }
	
	public static class SelectedRatedMoviesMapper extends Mapper<Object, Text, Text, IntWritable> 
	{        
        @Override
        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            String[] strArr = value.toString().split(splitCharSpace);

            if(strArr.length>0)
            {
            	int rating = Integer.parseInt(strArr[1].trim());
            	
            	context.write(new Text(strArr[0]), new IntWritable(rating));
            }
        }
    }
	
	public static class SelectedMoviesAverageRateReducer extends Reducer<Text, IntWritable, NullWritable, Text> {

		private Text outValue = new Text();
        @Override
        public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
        	double sum = 0;
            int count = 0;
            for (IntWritable val : values) {
                sum += val.get();
                count++;
            }
            
            double rating = sum/count;
            if(rating>=lowAvgRating && rating<=highAvgRating)
            {
            	String[] strArr = key.toString().trim().split(splitChar);

                if (strArr.length == 3) {
                    String mvId = strArr[0].trim();
                    String mvName = strArr[1].trim();
                    String mvGenre = strArr[2].trim();
                    outValue.set(mvId+"\t"+mvName+"\t"+mvGenre+"\t"+rating);    
                    
                    context.write(NullWritable.get(), outValue);
                }
            }
        }
    }
	
	/**
	 * @param args
	 */
	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws Exception
	{
		// TODO Auto-generated method stub
		Configuration conf = new Configuration();    
		
		if (args.length != 4) {
            System.err.println("Instruction: MoviesRSJoin <Users File Path> <Ratings File Path> <Movies File Path> <Output>");
            System.exit(2);
        }
		
		FileSystem fs = FileSystem.get(conf);
        fs.delete(new Path(args[3]));
        fs.delete(new Path(args[3]+"_usr_rat_join"));
        //fs.delete(new Path(args[3]+"_usr_rat_mv_join"));
        
	    Job joinJobOne = new Job(conf, "MoviesRSJoin");
		
		joinJobOne.setOutputKeyClass(Text.class);
	    joinJobOne.setOutputValueClass(Text.class);
	    
	    joinJobOne.setJarByClass(MoviesRSJoin.class);
	    joinJobOne.setMapperClass(RatingsMapper.class);
	    joinJobOne.setMapperClass(UsersMapper.class);
	    joinJobOne.setReducerClass(UsersRatingJoinReducer.class);
	        
	    joinJobOne.setMapOutputKeyClass(Text.class);
	    joinJobOne.setMapOutputValueClass(Text.class);
        
	    joinJobOne.setInputFormatClass(TextInputFormat.class);
	    joinJobOne.setOutputFormatClass(TextOutputFormat.class);
	    
	    MultipleInputs.addInputPath(joinJobOne, new Path(args[0]), TextInputFormat.class, UsersMapper.class);
		MultipleInputs.addInputPath(joinJobOne, new Path(args[1]), TextInputFormat.class, RatingsMapper.class);
		FileOutputFormat.setOutputPath(joinJobOne, new Path(args[3]+"_usr_rat_join"));
	    
	    //joinJobOne.waitForCompletion(true);
		if (joinJobOne.waitForCompletion(true)) {
	    	
            Job joinJobTwo = new Job(conf, "MoviesRatingsRSJoin");
            
            joinJobTwo.setOutputKeyClass(Text.class);
            joinJobTwo.setOutputValueClass(Text.class);
    	    
            joinJobTwo.setJarByClass(MoviesRSJoin.class);
            joinJobTwo.setMapperClass(MoviesMapper.class);
            joinJobTwo.setMapperClass(SelectedUsersRatingsMapper.class);
            joinJobTwo.setReducerClass(UsersRatingMoviesJoinReducer.class);
    	        
            joinJobTwo.setMapOutputKeyClass(Text.class);
            joinJobTwo.setMapOutputValueClass(Text.class);

            MultipleInputs.addInputPath(joinJobTwo, new Path(args[2]), TextInputFormat.class, MoviesMapper.class);
    		MultipleInputs.addInputPath(joinJobTwo, new Path(args[3]+"_usr_rat_join"), TextInputFormat.class, SelectedUsersRatingsMapper.class);
    		//FileOutputFormat.setOutputPath(joinJobTwo, new Path(args[3]+"_usr_rat_mv_join"));
    		FileOutputFormat.setOutputPath(joinJobTwo, new Path(args[3]));

            System.exit(joinJobTwo.waitForCompletion(true) ? 0 : 1);
//    		if (joinJobTwo.waitForCompletion(true)) {
//    			Job joinJobThree = new Job(conf, "SelectedRatedMovies");
//    			
//    			joinJobThree.setOutputKeyClass(NullWritable.class);
//    			joinJobThree.setOutputValueClass(Text.class);
//    		    
//    			joinJobThree.setJarByClass(MoviesRSJoin.class);
//    			joinJobThree.setMapperClass(SelectedRatedMoviesMapper.class);
//    			joinJobThree.setReducerClass(SelectedMoviesAverageRateReducer.class);
//    		        
//    			joinJobThree.setMapOutputKeyClass(Text.class);
//    			joinJobThree.setMapOutputValueClass(IntWritable.class);
//    	        
//    			joinJobThree.setInputFormatClass(TextInputFormat.class);
//    			joinJobThree.setOutputFormatClass(TextOutputFormat.class);
//    		    	        
//    		    FileInputFormat.addInputPath(joinJobThree, new Path(args[3]+"_usr_rat_mv_join"));
//    		    FileOutputFormat.setOutputPath(joinJobThree, new Path(args[3]));
//    		    
//    		    System.exit(joinJobThree.waitForCompletion(true) ? 0 : 1);
//    		}
        }
	}
}
